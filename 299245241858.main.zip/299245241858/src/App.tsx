import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { AuthContext } from './contexts/authContext';
import Home from './pages/Home';
import LoginPage from './pages/LoginPage';
import TestPage from './pages/TestPage';
import DeployGuide from './pages/DeployGuide';
import UserProfile from './pages/UserProfile';

// 定义用户信息接口
interface UserInfo {
  id: string;
  name: string;
  phone?: string;
  avatar?: string;
  points: number;
  inviteCode: string;
  registeredAt: string;
  lastLogin?: string;
}

function App() {
  // 用户认证状态
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);

  // 登录处理函数
  const login = (userData: UserInfo) => {
    setIsAuthenticated(true);
    setUserInfo(userData);
    // 保存到localStorage
    localStorage.setItem('userInfo', JSON.stringify(userData));
  };

  // 登出处理函数
  const logout = () => {
    setIsAuthenticated(false);
    setUserInfo(null);
    // 清除localStorage
    localStorage.removeItem('userInfo');
  };

  // 更新积分函数
  const updatePoints = (points: number) => {
    if (userInfo) {
      const updatedUserInfo = { ...userInfo, points };
      setUserInfo(updatedUserInfo);
      localStorage.setItem('userInfo', JSON.stringify(updatedUserInfo));
    }
  };

  // 初始化时检查localStorage是否有用户信息
  useState(() => {
    const savedUserInfo = localStorage.getItem('userInfo');
    if (savedUserInfo) {
      try {
        const parsedUserInfo = JSON.parse(savedUserInfo);
        setIsAuthenticated(true);
        setUserInfo(parsedUserInfo);
      } catch (error) {
        console.error('Failed to parse user info from localStorage:', error);
      }
    }
  });

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        userInfo,
        setIsAuthenticated,
        setUserInfo,
        logout,
        login,
        updatePoints,
      }}
    >
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/test" element={<TestPage />} />
        <Route path="/deploy" element={<DeployGuide />} />
        <Route path="/profile" element={<UserProfile />} />
      </Routes>
    </AuthContext.Provider>
  );
}

export default App;