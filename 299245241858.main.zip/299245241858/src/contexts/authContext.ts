// 定义用户信息接口
export interface UserInfo {
  id: string;
  name: string;
  phone?: string;
  avatar?: string;
  points: number;
  inviteCode: string;
  registeredAt: string;
  lastLogin?: string;
}

// 定义认证上下文接口
interface AuthContextType {
  isAuthenticated: boolean;
  userInfo: UserInfo | null;
  setIsAuthenticated: (value: boolean) => void;
  setUserInfo: (userInfo: UserInfo | null) => void;
  logout: () => void;
  login: (userInfo: UserInfo) => void;
  updatePoints: (points: number) => void;
}

import { createContext } from "react";

export const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  userInfo: null,
  setIsAuthenticated: (value: boolean) => {},
  setUserInfo: (userInfo: UserInfo | null) => {},
  logout: () => {},
  login: (userInfo: UserInfo) => {},
  updatePoints: (points: number) => {},
});