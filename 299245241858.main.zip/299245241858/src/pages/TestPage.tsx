import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';
import { 
  Upload, 
  BookOpen, 
  Image, 
  Volume2, 
  Download, 
  ChevronRight, 
  CheckCircle, 
  Clock,
  AlertCircle,
  Heart
} from 'lucide-react';
import { toast } from 'sonner';

export default function TestPage() {
  const { theme, isDark } = useTheme();
  const [step, setStep] = useState(1);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [selectedTheme, setSelectedTheme] = useState<string>('海底世界');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedBook, setGeneratedBook] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<{
    imageUpload: boolean;
    themeSelection: boolean;
    bookGeneration: boolean;
    voiceSynthesis: boolean;
    pdfDownload: boolean;
  }>({
    imageUpload: false,
    themeSelection: false,
    bookGeneration: false,
    voiceSynthesis: false,
    pdfDownload: false
  });

  // 模拟主题选项
  const themes = ['海底世界', '丛林探险', '太空漫游', '魔法城堡', '动物王国'];

  // 处理照片上传
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        setUploadedImage(dataUrl);
        setTestResults(prev => ({ ...prev, imageUpload: true }));
        toast.success('照片上传成功！');
      };
      reader.readAsDataURL(file);
    }
  };

  // 处理主题选择
  const handleThemeSelect = (theme: string) => {
    setSelectedTheme(theme);
    setTestResults(prev => ({ ...prev, themeSelection: true }));
    toast.success(`已选择主题：${theme}`);
  };

  // 模拟生成绘本
  const handleGenerateBook = () => {
    if (!uploadedImage) {
      toast.error('请先上传照片');
      return;
    }
    
    setIsGenerating(true);
    
    // 模拟生成过程（3秒）
    setTimeout(() => {
      // 模拟生成的绘本图片
      const mockBookUrl = "https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Children%20storybook%20cover%2C%20cartoon%20style%2C%20colorful&sign=d5f3643bd8e55de1a425b5a057865eac";
      setGeneratedBook(mockBookUrl);
      setIsGenerating(false);
      setTestResults(prev => ({ ...prev, bookGeneration: true }));
      toast.success('绘本生成成功！');
    }, 3000);
  };

  // 模拟语音合成测试
  const testVoiceSynthesis = () => {
    setTestResults(prev => ({ ...prev, voiceSynthesis: true }));
    toast.success('语音合成功能测试通过！');
  };

  // 模拟PDF下载测试
  const testPdfDownload = () => {
    setTestResults(prev => ({ ...prev, pdfDownload: true }));
    toast.success('PDF下载功能测试通过！');
  };

  // 进入下一步
  const nextStep = () => {
    if (step < 5) {
      setStep(step + 1);
    }
  };

  // 返回上一步
  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  // 检查所有测试是否通过
  const isAllTestsPassed = Object.values(testResults).every(result => result);

  return (
    <div className={cn('min-h-screen p-4', isDark ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-800')}>
      <div className="max-w-4xl mx-auto">
        {/* 页面标题 */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <h1 className="text-3xl font-bold mb-2">网站功能测试</h1>
          <p className="text-gray-600 dark:text-gray-300">
            按照步骤测试AI儿童绘本网站的核心功能
          </p>
        </motion.div>

        {/* 测试进度指示器 */}
        <div className="mb-8">
          <div className="flex justify-between items-center">
            {['照片上传', '主题选择', '绘本生成', '语音合成', 'PDF下载'].map((item, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 ${
                  step > index ? 'bg-green-500 text-white' : 
                  step === index ? 'bg-blue-500 text-white' : 
                  'bg-gray-300 dark:bg-gray-700'
                }`}>
                  {step > index ? <CheckCircle className="w-5 h-5" /> : index + 1}
                </div>
                <span className="text-xs text-center">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 测试步骤内容 */}
        <div className={`rounded-xl shadow-lg p-6 mb-6 ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
          {/* 步骤1：照片上传 */}
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              <h2 className="text-2xl font-bold">步骤1：测试照片上传</h2>
              <p className="text-gray-600 dark:text-gray-300">
                上传一张照片，测试图片处理功能是否正常工作
              </p>
              
              <div className="mt-6">
                <label htmlFor="image-upload" className={`
                  w-full h-48 border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer
                  ${uploadedImage ? 'border-green-500' : 'border-gray-300 dark:border-gray-600'}
                  ${isDark ? 'hover:bg-gray-700' : 'hover:bg-gray-50'}
                  transition-colors
                `}>
                  <input 
                    id="image-upload" 
                    type="file" 
                    accept="image/*" 
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  {uploadedImage ? (
                    <div className="w-full h-full relative">
                      <img 
                        src={uploadedImage} 
                        alt="预览" 
                        className="w-full h-full object-cover rounded-lg"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center rounded-lg">
                        <CheckCircle className="w-12 h-12 text-white" />
                      </div>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-12 h-12 text-gray-400" />
                      <span className="mt-2 text-gray-500 dark:text-gray-400">
                        点击或拖拽图片到这里上传
                      </span>
                    </>
                  )}
                </label>
              </div>
              
              <div className="mt-4">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  支持JPG、PNG等常见图片格式，文件大小不超过5MB
                </p>
              </div>
            </motion.div>
          )}

          {/* 步骤2：主题选择 */}
          {step === 2 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              <h2 className="text-2xl font-bold">步骤2：测试主题选择</h2>
              <p className="text-gray-600 dark:text-gray-300">
                从以下主题中选择一个，测试主题选择功能是否正常
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-6">
                {themes.map((theme, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`
                      p-4 rounded-lg cursor-pointer text-center
                      ${selectedTheme === theme 
                        ? 'bg-blue-100 dark:bg-blue-900 border-blue-500' 
                        : 'bg-gray-100 dark:bg-gray-700'}
                      border-2 transition-colors
                    `}
                    onClick={() => handleThemeSelect(theme)}
                  >
                    <BookOpen className={`w-8 h-8 mx-auto mb-2 ${
                      selectedTheme === theme ? 'text-blue-500' : 'text-gray-500'
                    }`} />
                    <span>{theme}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* 步骤3：绘本生成 */}
          {step === 3 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              <h2 className="text-2xl font-bold">步骤3：测试绘本生成</h2>
              <p className="text-gray-600 dark:text-gray-300">
                点击"生成绘本"按钮，测试AI生成绘本功能（模拟过程需要3秒）
              </p>
              
              <div className="mt-6 text-center">
                {isGenerating ? (
                  <div className="py-10">
                    <div className="mb-4 inline-block">
                      <Clock className="w-12 h-12 text-blue-500 animate-spin" />
                    </div>
                    <p className="text-gray-600 dark:text-gray-300">
                      正在生成绘本，请稍候...
                    </p>
                  </div>
                ) : generatedBook ? (
                  <div>
                    <div className="mb-4">
                      <img 
                        src={generatedBook} 
                        alt="生成的绘本" 
                        className="w-full max-w-md mx-auto rounded-lg shadow-md"
                      />
                    </div>
                    <p className="text-green-500 font-medium">
                      绘本生成成功！
                    </p>
                  </div>
                ) : (
                  <button
                    onClick={handleGenerateBook}
                    disabled={!uploadedImage}
                    className={`
                      px-8 py-3 rounded-full font-semibold transition-all
                      ${uploadedImage 
                        ? 'bg-blue-500 hover:bg-blue-600 text-white' 
                        : 'bg-gray-300 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'}
                    `}
                  >
                    生成绘本
                  </button>
                )}
              </div>
            </motion.div>
          )}

          {/* 步骤4：语音合成 */}
          {step === 4 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              <h2 className="text-2xl font-bold">步骤4：测试语音合成</h2>
              <p className="text-gray-600 dark:text-gray-300">
                点击"测试语音合成"按钮，测试AI语音朗读功能
              </p>
              
              <div className="mt-6 text-center">
                <div className="mb-6 inline-block p-6 bg-blue-100 dark:bg-blue-900 rounded-full">
                  <Volume2 className="w-16 h-16 text-blue-500" />
                </div>
                
                <button
                  onClick={testVoiceSynthesis}
                  className="px-8 py-3 bg-blue-500 hover:bg-blue-600 text-white font-semibold rounded-full transition-all"
                >
                  测试语音合成
                </button>
                
                {testResults.voiceSynthesis && (
                  <div className="mt-6 flex items-center justify-center text-green-500">
                    <CheckCircle className="w-5 h-5 mr-2" />
                    <span>语音合成功能测试通过</span>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {/* 步骤5：PDF下载 */}
          {step === 5 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              <h2 className="text-2xl font-bold">步骤5：测试PDF下载</h2>
              <p className="text-gray-600 dark:text-gray-300">
                点击"测试PDF下载"按钮，测试PDF导出功能
              </p>
              
              <div className="mt-6 text-center">
                <div className="mb-6 inline-block p-6 bg-amber-100 dark:bg-amber-900 rounded-full">
                  <Download className="w-16 h-16 text-amber-500" />
                </div>
                
                <button
                  onClick={testPdfDownload}
                  className="px-8 py-3 bg-amber-500 hover:bg-amber-600 text-white font-semibold rounded-full transition-all"
                >
                  测试PDF下载
                </button>
                
                {testResults.pdfDownload && (
                  <div className="mt-6 flex items-center justify-center text-green-500">
                    <CheckCircle className="w-5 h-5 mr-2" />
                    <span>PDF下载功能测试通过</span>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </div>

        {/* 测试结果总结 */}
        {step === 5 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`rounded-xl shadow-lg p-6 mb-6 ${isDark ? 'bg-gray-800' : 'bg-white'}`}
          >
            <h2 className="text-2xl font-bold mb-4">测试结果总结</h2>
            
            <div className="space-y-3">
              {Object.entries(testResults).map(([key, value], index) => (
                <div key={index} className="flex items-center">
                  <div className={`mr-3 ${value ? 'text-green-500' : 'text-red-500'}`}>
                    {value ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                  </div>
                  <span className="capitalize">
                    {key === 'imageUpload' ? '照片上传' : 
                     key === 'themeSelection' ? '主题选择' : 
                     key === 'bookGeneration' ? '绘本生成' : 
                     key === 'voiceSynthesis' ? '语音合成' : 'PDF下载'}
                    ：{value ? '通过' : '未通过'}
                  </span>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 rounded-lg text-center font-medium text-white"
                 style={{ backgroundColor: isAllTestsPassed ? '#10b981' : '#f43f5e' }}>
              {isAllTestsPassed 
                ? '恭喜！所有功能测试通过，网站运行正常。' 
                : '部分功能测试未通过，请检查问题后重试。'}
            </div>
          </motion.div>
        )}

        {/* 导航按钮 */}
        <div className="flex justify-between">
          <button
            onClick={prevStep}
            disabled={step === 1}
            className={`
              px-6 py-2 rounded-full font-medium transition-all
              ${step > 1 
                ? 'bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600' 
                : 'bg-gray-200 dark:bg-gray-800 text-gray-400 cursor-not-allowed'}
            `}
          >
            上一步
          </button>
          
          {step < 5 ? (
            <button
              onClick={nextStep}
              disabled={
                (step === 1 && !uploadedImage) ||
                (step === 3 && !generatedBook && !isGenerating)
              }
              className={`
                px-6 py-2 rounded-full font-medium transition-all
                ${(!(step === 1 && !uploadedImage) && !(step === 3 && !generatedBook && !isGenerating))
                  ? 'bg-blue-500 hover:bg-blue-600 text-white' 
                  : 'bg-gray-200 dark:bg-gray-800 text-gray-400 cursor-not-allowed'}
              `}
            >
              下一步 <ChevronRight className="inline-block w-4 h-4 ml-1" />
            </button>
          ) : (
            <button
              onClick={() => setStep(1)}
              className="px-6 py-2 bg-green-500 hover:bg-green-600 text-white font-medium rounded-full transition-all"
            >
              重新测试
            </button>
          )}
        </div>

         {/* 测试说明 */}
        <div className={`mt-8 p-4 rounded-lg text-sm ${isDark ? 'bg-gray-800 text-gray-300' : 'bg-gray-100 text-gray-600'}`}>
          <h3 className="font-bold mb-2 flex items-center">
            <AlertCircle className="w-4 h-4 mr-2" /> 测试说明
          </h3>
          <ul className="list-disc pl-5 space-y-1">
            <li>此测试页面用于验证网站核心功能是否正常工作</li>
            <li>测试使用模拟数据，不涉及真实的AI处理过程</li>
            <li>实际使用时，生成绘本可能需要3-5分钟时间</li>
            <li>如测试过程中遇到问题，请刷新页面后重试</li>
            <li>如需将网站部署上线，请查看我们的<a href="/deploy" className="text-blue-500 hover:underline">部署指南</a></li>
          </ul>
        </div>
      </div>
    </div>
  );
}