import { useContext, useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '@/contexts/authContext';
import { toast } from 'sonner';
import {
  User,
  Coins,
  Gift,
  Share2,
  History,
  Settings,
  BookOpen,
  Download,
  LogOut,
  ChevronRight,
  Calendar
} from 'lucide-react';

export default function UserProfile() {
  const { theme, isDark } = useTheme();
  const { userInfo, logout, updatePoints } = useContext(AuthContext);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const navigate = useNavigate();

  // 如果用户未登录，重定向到登录页面
  if (!userInfo) {
    navigate('/login');
    return null;
  }

  // 模拟积分使用
  const handleUsePoints = (points: number, action: string) => {
    if (userInfo.points >= points) {
      updatePoints(userInfo.points - points);
      toast.success(`成功消耗 ${points} 积分，${action}`);
    } else {
      toast.error(`积分不足，需要 ${points} 积分`);
    }
  };

  // 模拟复制邀请码
  const copyInviteCode = () => {
    navigator.clipboard.writeText(userInfo.inviteCode)
      .then(() => {
        toast.success('邀请码已复制到剪贴板');
      })
      .catch(() => {
        toast.error('复制失败，请手动复制');
      });
  };

  // 模拟分享邀请码
  const shareInviteCode = () => {
    // 在实际应用中，这里会调用微信分享API
    toast.info('微信分享功能已触发（模拟）');
    setShowInviteModal(false);
  };

  // 格式化日期
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
  };

  return (
    <div className={cn('min-h-screen', isDark ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-800')}>
      {/* 顶部栏 */}
      <div className={`py-6 px-4 ${isDark ? 'bg-gray-800' : 'bg-white'} shadow-sm sticky top-0 z-10`}>
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold">个人中心</h1>
          <button 
            onClick={() => navigate(-1)}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* 用户信息卡片 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`rounded-2xl p-6 mb-6 shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}
        >
          <div className="flex items-center">
            <div className="h-16 w-16 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-500 mr-4">
              <User className="h-8 w-8" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{userInfo.name}</h2>
              {userInfo.phone && (
                <p className="text-gray-600 dark:text-gray-300">{userInfo.phone}</p>
              )}
              <div className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                注册时间：{formatDate(userInfo.registeredAt)}
              </div>
            </div>
          </div>

          {/* 积分显示 */}
          <div className="mt-6 grid grid-cols-3 gap-4">
            <div className={`p-4 rounded-xl ${isDark ? 'bg-gray-700' : 'bg-yellow-50'} flex flex-col items-center`}>
              <Coins className="h-6 w-6 text-yellow-500 mb-2" />
              <span className="text-lg font-bold">{userInfo.points}</span>
              <span className="text-sm text-gray-500 dark:text-gray-400">我的积分</span>
            </div>
            <div className={`p-4 rounded-xl ${isDark ? 'bg-gray-700' : 'bg-blue-50'} flex flex-col items-center`}>
              <BookOpen className="h-6 w-6 text-blue-500 mb-2" />
              <span className="text-lg font-bold">0</span>
              <span className="text-sm text-gray-500 dark:text-gray-400">我的绘本</span>
            </div>
            <div className={`p-4 rounded-xl ${isDark ? 'bg-gray-700' : 'bg-green-50'} flex flex-col items-center`}>
              <Gift className="h-6 w-6 text-green-500 mb-2" />
              <span className="text-lg font-bold">0</span>
              <span className="text-sm text-gray-500 dark:text-gray-400">我的奖励</span>
            </div>
          </div>
        </motion.div>

        {/* 积分使用说明 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className={`rounded-2xl p-6 mb-6 shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}
        >
          <h3 className="text-lg font-bold mb-4">积分使用说明</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <BookOpen className="h-5 w-5 text-blue-500 mr-2" />
                <span>生成一个故事</span>
              </div>
              <span className="text-red-500">-1 积分</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Download className="h-5 w-5 text-amber-500 mr-2" />
                <span>下载PDF</span>
              </div>
              <span className="text-red-500">-3 积分</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Gift className="h-5 w-5 text-green-500 mr-2" />
                <span>邀请好友注册</span>
              </div>
              <span className="text-green-500">+5 积分</span>
            </div>
          </div>
          
           {/* 积分操作按钮 */}
          <div className="mt-6 grid grid-cols-2 gap-4">
            <button
              onClick={() => handleUsePoints(1, '生成故事')}
              className={`py-3 rounded-lg font-medium transition-all ${
                isDark 
                  ? 'bg-blue-900 hover:bg-blue-800 text-white' 
                  : 'bg-blue-50 hover:bg-blue-100 text-blue-600'
              }`}
            >
              生成故事（-1积分）
            </button>
            <button
              onClick={() => handleUsePoints(3, '下载PDF')}
              className={`py-3 rounded-lg font-medium transition-all ${
                isDark 
                  ? 'bg-amber-900 hover:bg-amber-800 text-white' 
                  : 'bg-amber-50 hover:bg-amber-100 text-amber-600'
              }`}
            >
              下载PDF（-3积分）
            </button>
          </div>
        </motion.div>

        {/* 邀请好友 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className={`rounded-2xl p-6 mb-6 shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}
        >
          <div 
            onClick={() => setShowInviteModal(true)}
            className="flex justify-between items-center cursor-pointer"
          >
            <div className="flex items-center">
              <Share2 className="h-5 w-5 text-green-500 mr-2" />
              <span className="font-medium">邀请好友</span>
            </div>
            <ChevronRight className="h-5 w-5 text-gray-400" />
          </div>
          <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
            邀请好友注册，您和好友都可以获得5积分奖励
          </p>
        </motion.div>

        {/* 菜单列表 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className={`rounded-2xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}
        >
          <div className="border-b border-gray-200 dark:border-gray-700">
            <button className="w-full flex justify-between items-center p-6 text-left">
              <div className="flex items-center">
                <History className="h-5 w-5 text-gray-500 mr-2" />
                <span>历史记录</span>
              </div>
              <ChevronRight className="h-5 w-5 text-gray-400" />
            </button>
          </div>
          <div className="border-b border-gray-200 dark:border-gray-700">
            <button className="w-full flex justify-between items-center p-6 text-left">
              <div className="flex items-center">
                <Calendar className="h-5 w-5 text-gray-500 mr-2" />
                <span>积分明细</span>
              </div>
              <ChevronRight className="h-5 w-5 text-gray-400" />
            </button>
          </div>
          <div>
            <button className="w-full flex justify-between items-center p-6 text-left">
              <div className="flex items-center">
                <Settings className="h-5 w-5 text-gray-500 mr-2" />
                <span>设置</span>
              </div>
              <ChevronRight className="h-5 w-5 text-gray-400" />
            </button>
          </div>
        </motion.div>

        {/* 退出登录按钮 */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          onClick={() => {
            logout();
            navigate('/');
          }}
          className={`w-full mt-8 py-4 rounded-xl text-red-500 font-medium transition-all ${
            isDark 
              ? 'bg-red-900/20 hover:bg-red-900/30' 
              : 'bg-red-50 hover:bg-red-100'
          }`}
        >
          <div className="flex items-center justify-center">
            <LogOut className="h-5 w-5 mr-2" />
            退出登录
          </div>
        </motion.button>
      </div>

      {/* 邀请码模态框 */}
      {showInviteModal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          onClick={() => setShowInviteModal(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className={`rounded-2xl p-6 max-w-md w-full ${isDark ? 'bg-gray-800' : 'bg-white'}`}
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-xl font-bold mb-4">邀请好友</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              分享您的邀请码给好友，好友注册后您将获得5积分奖励
            </p>
            
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">您的邀请码</label>
              <div className="flex space-x-3">
                <div className={`flex-1 py-3 px-4 rounded-lg font-mono text-center ${
                  isDark ? 'bg-gray-700' : 'bg-gray-100'
                }`}>
                  {userInfo.inviteCode}
                </div>
                <button
                  onClick={copyInviteCode}
                  className={`py-3 px-4 rounded-lg font-medium ${
                    isDark 
                      ? 'bg-blue-900 hover:bg-blue-800 text-white' 
                      : 'bg-blue-100 hover:bg-blue-200 text-blue-600'
                  }`}
                >
                  复制
                </button>
              </div>
            </div>
            
            <button
              onClick={shareInviteCode}
              className="w-full py-3 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-full transition-colors flex items-center justify-center"
            >
              <Share2 className="h-5 w-5 mr-2" />
              分享给微信好友
            </button>
            
            <button
              onClick={() => setShowInviteModal(false)}
              className={`w-full mt-4 py-3 ${
                isDark 
                  ? 'bg-gray-700 hover:bg-gray-600' 
                  : 'bg-gray-200 hover:bg-gray-300'
              } font-medium rounded-full transition-colors`}
            >
              关闭
            </button>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}