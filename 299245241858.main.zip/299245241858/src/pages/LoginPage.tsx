import { useState, useContext } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '@/contexts/authContext';
import { toast } from 'sonner';
import {
  Phone,
  Lock,
  Eye,
  EyeOff,
  ArrowLeft,
  MessageSquare
} from 'lucide-react';

export default function LoginPage() {
  const { theme, isDark } = useTheme();
  const [loginMethod, setLoginMethod] = useState<'wechat' | 'phone'>('wechat');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [countdown, setCountdown] = useState(0);
  const navigate = useNavigate();
  const { login } = useContext(AuthContext);

  // 模拟发送验证码
  const sendVerificationCode = () => {
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      toast.error('请输入正确的手机号码');
      return;
    }
    
    // 开始倒计时
    setCountdown(60);
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    toast.success('验证码已发送');
  };

  // 模拟微信登录
  const handleWechatLogin = () => {
    // 模拟登录成功，创建一个用户信息对象
    const mockUser: any = {
      id: `wx_${Date.now()}`,
      name: '微信用户',
      points: 10, // 新用户初始积分10分
      inviteCode: generateInviteCode(),
      registeredAt: new Date().toISOString()
    };
    
    login(mockUser);
    toast.success('微信登录成功');
    navigate('/');
  };

  // 模拟手机号登录
  const handlePhoneLogin = () => {
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      toast.error('请输入正确的手机号码');
      return;
    }
    
    if (!verificationCode || verificationCode.length !== 6 || !/^\d+$/.test(verificationCode)) {
      toast.error('请输入6位数字验证码');
      return;
    }
    
    // 模拟登录成功，创建一个用户信息对象
    const mockUser: any = {
      id: `phone_${Date.now()}`,
      name: `用户${phone.slice(-4)}`,
      phone,
      points: 10, // 新用户初始积分10分
      inviteCode: generateInviteCode(),
      registeredAt: new Date().toISOString()
    };
    
    login(mockUser);
    toast.success('登录成功');
    navigate('/');
  };

  // 生成邀请码
  const generateInviteCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 排除容易混淆的字符
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  return (
    <div className={cn('min-h-screen flex items-center justify-center p-4', isDark ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-800')}>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`w-full max-w-md rounded-2xl shadow-lg p-8 ${isDark ? 'bg-gray-800' : 'bg-white'}`}
      >
        {/* 返回按钮 */}
        <div className="mb-8">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
        </div>

        {/* 登录标题 */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">欢迎登录</h1>
          <p className="text-gray-600 dark:text-gray-300">
            登录后即可创建专属绘本，获得更多积分奖励
          </p>
        </div>

        {/* 登录方式选择 */}
        <div className="flex mb-8 border-b border-gray-200 dark:border-gray-700">
          <button
            className={`flex-1 py-3 font-medium ${
              loginMethod === 'wechat' 
                ? 'border-b-2 border-blue-500 text-blue-500' 
                : 'text-gray-500 dark:text-gray-400'
            }`}
            onClick={() => setLoginMethod('wechat')}
          >
            微信登录
          </button>
          <button
            className={`flex-1 py-3 font-medium ${
              loginMethod === 'phone' 
                ? 'border-b-2 border-blue-500 text-blue-500' 
                : 'text-gray-500 dark:text-gray-400'
            }`}
            onClick={() => setLoginMethod('phone')}
          >
            手机号登录
          </button>
        </div>

        {/* 微信登录表单 */}
        {loginMethod === 'wechat' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            <div className="text-center py-6">
               <div 
                onClick={handleWechatLogin}
                className="mx-auto w-24 h-24 rounded-full bg-green-50 dark:bg-green-900/30 flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
              >
                <i className="fa-brands fa-weixin text-4xl text-green-500" />
              </div>
              <p className="mt-4 text-gray-600 dark:text-gray-300">
                点击微信图标进行登录
              </p>
            </div>
            <button
              onClick={handleWechatLogin}
              className="w-full py-3 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-full transition-colors flex items-center justify-center"
            >
              <i className="fa-brands fa-weixin text-lg mr-2" />
              使用微信账号登录
            </button>
          </motion.div>
        )}

        {/* 手机号登录表单 */}
        {loginMethod === 'phone' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            <div className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="phone" className="block text-sm font-medium">
                  手机号码
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="tel"
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="请输入手机号码"
                    className={`w-full pl-10 pr-3 py-3 border ${
                      isDark 
                        ? 'border-gray-700 bg-gray-900' 
                        : 'border-gray-300 bg-white'
                    } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all`}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="verification-code" className="block text-sm font-medium">
                  验证码
                </label>
                <div className="flex space-x-3">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <MessageSquare className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      id="verification-code"
                      value={verificationCode}
                      onChange={(e) => setVerificationCode(e.target.value)}
                      placeholder="请输入验证码"
                      className={`w-full pl-10 pr-3 py-3 border ${
                        isDark 
                          ? 'border-gray-700 bg-gray-900' 
                          : 'border-gray-300 bg-white'
                      } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all`}
                    />
                  </div>
                  <button
                    onClick={sendVerificationCode}
                    disabled={countdown > 0}
                    className={`whitespace-nowrap px-4 py-3 rounded-lg font-medium transition-all ${
                      countdown > 0
                        ? 'bg-gray-300 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                        : 'bg-blue-500 hover:bg-blue-600 text-white'
                    }`}
                  >
                    {countdown > 0 ? `重新发送(${countdown})` : '获取验证码'}
                  </button>
                </div>
              </div>
            </div>
            
            <button
              onClick={handlePhoneLogin}
              className="w-full py-3 bg-blue-500 hover:bg-blue-600 text-white font-semibold rounded-full transition-colors"
            >
              登录
            </button>
          </motion.div>
        )}

        {/* 其他信息 */}
        <div className="mt-8 text-center text-sm text-gray-500 dark:text-gray-400">
          <p>登录即表示您同意我们的</p>
          <p className="mt-1">
            <a href="#" className="text-blue-500 hover:underline">用户协议</a> 和 
            <a href="#" className="text-blue-500 hover:underline ml-1">隐私政策</a>
          </p>
        </div>
      </motion.div>
    </div>
  );
}