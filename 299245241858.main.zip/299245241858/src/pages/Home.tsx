import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import { AuthContext } from '@/contexts/authContext';
import {
  BookOpen,
  Image,
  Volume2,
  Download,
  Moon,
  Sun,
  ChevronRight,
  User,
  Heart,
  Upload,
  Clock,
  BookMarked,
  Download as DownloadIcon
} from 'lucide-react';

// 登录按钮组件
function AuthButton() {
  const { isAuthenticated, userInfo, logout } = React.useContext(AuthContext);
  const navigate = useNavigate();
  
  if (isAuthenticated && userInfo) {
    return (
      <div className="relative group">
        <button className="flex items-center space-x-2 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
          <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-500">
            <User className="h-4 w-4" />
          </div>
          <span className="text-sm font-medium">{userInfo.name}</span>
        </button>
        <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-500">
                <User className="h-5 w-5" />
              </div>
              <div>
                <p className="font-medium">{userInfo.name}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center">
                  <i className="fa-solid fa-coins text-yellow-500 mr-1"></i>
                  {userInfo.points} 积分
                </p>
              </div>
            </div>
          </div>
          <div className="p-2">
            <button 
              onClick={() => navigate('/profile')}
              className="w-full text-left px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center text-sm"
            >
              <i className="fa-solid fa-user mr-2 text-gray-500"></i>
              个人中心
            </button>
            <button 
              onClick={() => {
                logout();
                navigate('/');
              }}
              className="w-full text-left px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center text-sm"
            >
              <i className="fa-solid fa-sign-out-alt mr-2 text-gray-500"></i>
              退出登录
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <button 
      onClick={() => navigate('/login')}
      className="px-4 py-2 rounded-full bg-blue-500 hover:bg-blue-600 text-white font-medium transition-colors"
    >
      登录/注册
    </button>
  );
}

// 大类按钮组件
function CategoryButton(props: { 
  category: { 
    id: string; 
    title: string; 
    description: string; 
    icon: string; 
    color: string; 
    image: string;
    items: { title: string; desc: string }[] 
  }; 
  isDark: boolean 
}) {
  // 状态管理：控制大类是否展开
  const [isExpanded, setIsExpanded] = useState(false);
  
  // 切换展开/折叠状态
  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };
  
  // 解构props
  const { category, isDark } = props;
  
  // 根据颜色获取对应的背景和文本颜色
  const getColorClasses = (color: string) => {
    switch(color) {
      case 'blue':
        return {
          bg: 'bg-blue-100 dark:bg-blue-900',
          text: 'text-blue-500',
          lightBg: 'bg-blue-50',
          darkBg: 'bg-gray-700'
        };
      case 'pink':
        return {
          bg: 'bg-pink-100 dark:bg-pink-900',
          text: 'text-pink-500',
          lightBg: 'bg-pink-50',
          darkBg: 'bg-gray-700'
        };
      case 'orange':
        return {
          bg: 'bg-orange-100 dark:bg-orange-900',
          text: 'text-orange-500',
          lightBg: 'bg-orange-50',
          darkBg: 'bg-gray-700'
        };
      case 'purple':
        return {
          bg: 'bg-purple-100 dark:bg-purple-900',
          text: 'text-purple-500',
          lightBg: 'bg-purple-50',
          darkBg: 'bg-gray-700'
        };
      default:
        return {
          bg: 'bg-gray-100 dark:bg-gray-800',
          text: 'text-gray-500',
          lightBg: 'bg-gray-50',
          darkBg: 'bg-gray-700'
        };
    }
  };
  
  const colors = getColorClasses(category.color);
  
  return (
    <div>
      {/* 大类按钮 */}
      <motion.button
        onClick={toggleExpand}
        className={`w-full flex items-center justify-between p-6 rounded-xl shadow-lg ${
          isDark ? 'bg-gray-800' : 'bg-white'
        } transition-all`}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
      >
        <div className="flex items-center w-full">
          <div className="mr-4 flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden">
            <img 
              src={category.image} 
              alt={category.title} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-grow">
            <div className="flex items-center mb-2">
              <div className={`w-8 h-8 rounded-full ${colors.bg} flex items-center justify-center ${colors.text} mr-2`}>
                <i className={`fa-solid ${category.icon} text-sm`}></i>
              </div>
              <h3 className="text-xl font-bold">{category.title}</h3>
            </div>
            <p className="text-gray-600 dark:text-gray-300 text-sm">
              {category.description}
            </p>
          </div>
          <div className={`w-8 h-8 rounded-full ${colors.bg} flex items-center justify-center ${colors.text} ml-4 transform transition-transform ${
            isExpanded ? 'rotate-180' : ''
          }`}>
            <i className="fa-solid fa-chevron-down text-sm"></i>
          </div>
        </div>
      </motion.button>
      
      {/* 小类内容 - 根据展开状态显示/隐藏 */}
      <motion.div
        initial={false}
        animate={{ 
          height: isExpanded ? 'auto' : 0,
          opacity: isExpanded ? 1 : 0
        }}
        transition={{ duration: 0.3 }}
        className="overflow-hidden"
      >
        <div className={`p-6 pt-8 ml-6 mr-6 border-l border-r border-b rounded-b-xl shadow-lg -mt-1 ${
          isDark ? 'bg-gray-800' : 'bg-white'
        }`}>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {category.items.map((item, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className={`p-5 rounded-xl shadow-md hover:shadow-lg transition-all ${
                  isDark ? colors.darkBg : colors.lightBg
                }`}
              >
                <h4 className="font-bold mb-2">{item.title}</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">{item.desc}</p>
                <button
                  className={`mt-4 px-4 py-2 rounded-full text-sm font-medium ${
                    colors.text
                  } border border-current hover:bg-opacity-10 hover:bg-current transition-colors`}
                >
                  生成绘本
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function Home() {
  const { theme, toggleTheme, isDark } = useTheme();
  
  // 核心功能卡片数据
  const features = [
    {
      title: "儿童卡通形象生成",
      description: "上传孩子照片，AI自动生成可爱的卡通形象",
      icon: <Image className="h-10 w-10 text-blue-500" />
    },
    {
      title: "多主题绘本选择",
      description: "海底世界、丛林探险、太空漫游等多种主题",
      icon: <BookOpen className="h-10 w-10 text-green-500" />
    },
    {
      title: "AI语音朗读",
      description: "专业AI配音，让绘本内容生动起来",
      icon: <Volume2 className="h-10 w-10 text-purple-500" />
    },
     {
      title: "爸妈声音克隆",
      description: "录制爸爸或妈妈声音，让宝宝听到熟悉的讲故事声音",
      icon: <Volume2 className="h-10 w-10 text-pink-500" />
    },
    {
      title: "专属陪伴声音克隆",
      description: "录制祖辈或孩子喜欢的某个人的声音，带来独特的陪伴体验",
      icon: <Volume2 className="h-10 w-10 text-orange-500" />
    },
    {
      title: "PDF下载打印",
      description: "一键下载高清PDF，随时打印阅读",
      icon: <Download className="h-10 w-10 text-amber-500" />
    }
  ];
  
  // 主题展示数据
  const themes = [
    {
      name: "海底世界",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Underwater%20world%2C%20colorful%20coral%20reefs%2C%20fish%2C%20cartoon%20style&sign=51561d978a26bcc8244cd7844b026eef"
    },
    {
      name: "丛林探险",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Jungle%20adventure%2C%20wild%20animals%2C%20lush%20vegetation%2C%20cartoon%20style&sign=9df344e9da3a1b5cbdf84fcd6069c6f0"
    },
    {
      name: "太空漫游",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Space%20adventure%2C%20planets%2C%20spaceship%2C%20stars%2C%20cartoon%20style&sign=a2d04b94d3550aacfa69c26e2b8b2a5d"
    }
  ];
  
  // 产品优势数据
  const advantages = [
    {
      title: "个性化定制",
      description: "基于孩子的照片、年龄和喜好，定制专属绘本"
    },
    {
      title: "激发想象力",
      description: "丰富的主题和生动的插图，培养孩子的阅读兴趣"
    },
    {
      title: "高质量内容",
      description: "专业团队创作的故事模板，AI智能生成独特情节"
    }
  ];
  
  return (
    <div className={cn('min-h-screen bg-gradient-to-b', 
      isDark ? 'from-gray-900 to-gray-800 text-white' : 'from-blue-50 to-white text-gray-800')}>
       {/* 导航栏 */}
      <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center space-x-2"
        >
          <BookOpen className="h-8 w-8 text-blue-500" />
           <span className="text-xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text text-transparent">
            小故事家
          </span>
        </motion.div>
        
        <div className="flex items-center space-x-6">
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
          <AuthButton />
        </div>
      </nav>
      
      {/* 英雄区域 */}
      <section className="container mx-auto px-4 py-16 md:py-24 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            为您的孩子创造<span className="bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text text-transparent">专属童话故事</span>
          </h1>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-10 text-gray-600 dark:text-gray-300">
            利用AI技术，将您孩子的照片转化为生动有趣的绘本主角，定制独一无二的阅读体验
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-full shadow-lg hover:shadow-xl transition-all"
            >
              开始创作绘本
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-3 bg-white dark:bg-gray-800 text-gray-800 dark:text-white font-semibold rounded-full shadow-lg hover:shadow-xl transition-all border border-gray-200 dark:border-gray-700"
            >
              了解更多
            </motion.button>
          </div>
        </motion.div>
        
        {/* 轮播展示区 */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-16 max-w-5xl mx-auto relative"
        >
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl overflow-hidden p-2 md:p-6">
            <div className="flex overflow-x-auto gap-4 pb-4 hide-scrollbar">
              <div className="flex-shrink-0 w-72 h-96 relative rounded-xl overflow-hidden shadow-lg">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Children%20storybook%20illustration%2C%20cartoon%20style%2C%20colorful&sign=51daeee21183b4897fba900dcf834507" 
                  alt="绘本展示" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <p className="text-white font-bold">宝贝专属海底大冒险</p>
                </div>
              </div>
              <div className="flex-shrink-0 w-72 h-96 relative rounded-xl overflow-hidden shadow-lg">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Children%20storybook%20illustration%2C%20cartoon%20animal%20friends%2C%20forest%20adventure&sign=7e63986c9c646beeb0bd7ba71785f301" 
                  alt="绘本展示" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <p className="text-white font-bold">宝贝专属丛林历险记</p>
                </div>
              </div>
              <div className="flex-shrink-0 w-72 h-96 relative rounded-xl overflow-hidden shadow-lg">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Children%20storybook%20illustration%2C%20cartoon%20space%20adventure%2C%20stars%20and%20planets&sign=dd1c0e18f4faacbcb7aec1c2a7581fe1" 
                  alt="绘本展示" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <p className="text-white font-bold">宝贝专属太空漫游记</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>
      
      {/* 核心功能 */}
      <section className={`py-20 ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">我们的核心功能</h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              利用先进的AI技术，为您和孩子打造全新的阅读体验
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`p-6 rounded-xl shadow-lg hover:shadow-xl transition-all ${isDark ? 'bg-gray-700 hover:bg-gray-650' : 'bg-blue-50 hover:bg-blue-100'}`}
              >
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-300">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
         {/* 主题选择 */}
         <section className="py-20 container mx-auto px-4">
           <motion.div 
             initial={{ opacity: 0 }}
             whileInView={{ opacity: 1 }}
             viewport={{ once: true }}
             className="text-center mb-16"
           >
             <h2 className="text-3xl md:text-4xl font-bold mb-4">丰富的绘本主题</h2>
             <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
               多种精彩主题，满足不同孩子的兴趣爱好
             </p>
           </motion.div>

           {/* 主题分类菜单 - 使用状态管理展开/折叠 */}
           <div className="space-y-8">
             {[
               {
                 id: "cognitive",
                 title: "认知启蒙类",
                 description: "知识学习 + 习惯养成，主打科普启蒙 + 生活化适配",
                 icon: "fa-lightbulb",
                 color: "blue",
                 image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Children%20learning%20through%20storybook%2C%20colorful%2C%20education%20theme&sign=babaa5704d6a87e8ba3354826dc613a0",
                 items: [
                   { title: "萌娃专属小百科：生活常识篇", desc: "定制孩子日常场景（穿衣、洗漱、交通），用故事传递基础生活知识" },
                   { title: "宝贝的自然科普专属课", desc: "聚焦植物、昆虫、天气等自然现象，融入简单科学原理" },
                   { title: "为TA定制的职业体验小百科", desc: "让孩子化身喜欢的职业（医生、消防员、面包师），科普职业基础技能" },
                   { title: "萌娃的节气专属认知故事", desc: "结合24节气与地域习俗，贴近生活的节气科普" },
                   { title: "宝贝的食物科普奇妙之旅", desc: "围绕孩子爱吃的食物，讲解食物来源与营养" },
                   { title: "萌娃专属好习惯养成小百科", desc: "针对刷牙、整理玩具、按时睡觉等习惯，用故事引导主动养成" }
                 ]
               },
               {
                 id: "emotional",
                 title: "情感陪伴类",
                 description: "亲情 / 友谊 + 情绪管理，主打温馨治愈 + 情感共鸣",
                 icon: "fa-heart",
                 color: "pink",
                 image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Family%20love%20storybook%2C%20warm%20and%20heartwarming%20scene&sign=9ec2a48185c41cc627a1ebaf347c507e",
                 items: [
                   { title: "宝贝的亲情陪伴专属日记", desc: "定制孩子与家人的互动，记录温馨瞬间" },
                   { title: "萌娃的情绪小剧场：专属表达课", desc: "围绕生气、委屈、开心等情绪，帮孩子认知并表达情绪" },
                   { title: "为TA定制的友谊成长故事", desc: "融入孩子的小伙伴，培养社交能力" },
                   { title: "宝贝的宠物专属陪伴记", desc: "让孩子的宠物成为主角，传递责任与陪伴的意义" },
                   { title: "萌娃的节日专属温情故事", desc: "绑定生日、儿童节、春节等节日，打造有纪念意义的情感绘本" },
                   { title: "宝贝的异地陪伴专属篇章", desc: "针对亲子异地，缓解分离焦虑，传递思念" }
                 ]
               },
               {
                 id: "courage",
                 title: "勇气培养类",
                 description: "克服恐惧 + 挑战自我，主打趣味冒险 + 成长激励",
                 icon: "fa-shield",
                 color: "orange",
                 image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Adventure%20storybook%20with%20child%20hero%2C%20courage%20theme&sign=72f8436b544d754aa9518c190c72d07c",
                 items: [
                   { title: "萌娃的勇敢闯关专属记", desc: "定制孩子的小挑战（第一次独自上学、怕黑、不敢发言）" },
                   { title: "宝贝的探险挑战专属故事", desc: "轻度冒险场景，培养解决问题的勇气" },
                   { title: "为TA定制的挫折成长小剧场", desc: "围绕失败与坚持，传递'不放弃'的信念" },
                   { title: "萌娃的社交勇气专属冒险", desc: "针对怕陌生、不敢主动交友，鼓励社交突破" },
                   { title: "宝贝的未知探索专属之旅", desc: "探索陌生场景，克服对未知的恐惧" },
                   { title: "萌娃的小勇士专属救援记", desc: "轻度'救援'情节，强化责任与勇气" }
                 ]
               },
               {
                 id: "creative",
                 title: "创意想象类",
                 description: "天马行空 + 奇幻场景，主打趣味冒险 + 想象激发",
                 icon: "fa-magic",
                 color: "purple",
                 image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Fantasy%20storybook%20for%20children%2C%20magic%20and%20imagination&sign=40ed906b628ac59ae1adccf6af9024da",
                 items: [
                   { title: "宝贝的王子/公主专属奇遇记", desc: "定制孩子专属皇室身份，搭配魔法元素，讲述守护城堡、帮助他人的童话" },
                   { title: "萌娃的恐龙世界专属探险", desc: "穿越到恐龙时代，定制孩子喜欢的恐龙，情节轻松无恐惧" },
                   { title: "为TA定制的梦境奇幻之旅", desc: "以孩子的梦境为背景，融入孩子喜欢的玩具、动画角色" },
                   { title: "宝贝的魔法小镇专属奇遇", desc: "轻魔法场景，激发想象力" },
                   { title: "萌娃的童话改编专属故事", desc: "改编经典童话，主角替换成孩子" },
                   { title: "宝贝的太空幻想专属篇章", desc: "超现实太空场景，放飞创意想象" }
                 ]
               }
             ].map((category, categoryIndex) => (
               <motion.div
                 key={category.id}
                 initial={{ opacity: 0, y: 20 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true }}
                 transition={{ delay: categoryIndex * 0.1 }}
               >
                 {/* 大类按钮 - 可点击展开/折叠 */}
                 <CategoryButton 
                   category={category} 
                   isDark={isDark} 
                 />
               </motion.div>
             ))}
           </div>
         </section>
      
      {/* 产品优势 */}
      <section className={`py-20 ${isDark ? 'bg-gray-800' : 'bg-blue-50'}`}>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-2 lg:order-1"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">为什么选择我们？</h2>
              <div className="space-y-6">
                {advantages.map((advantage, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex gap-4"
                  >
                    <div className="flex-shrink-0 h-12 w-12 rounded-full bg-blue-500 flex items-center justify-center text-white">
                      {index + 1}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">{advantage.title}</h3>
                      <p className="text-gray-600 dark:text-gray-300">{advantage.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-1 lg:order-2"
            >
              <div className="relative">
                <div className="absolute -top-4 -left-4 w-full h-full bg-purple-400 rounded-2xl"></div>
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mother%20and%20child%20reading%20storybook%20together%2C%20happy%20family%20moment&sign=254d1ed98726568ee23ad8dbeaeb607d" 
                  alt="亲子阅读" 
                  className="relative z-10 rounded-2xl shadow-xl w-full"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* 用户见证 */}
      <section className="py-20 container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">用户的真实评价</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            看看其他家长对我们产品的评价
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1, 2, 3].map((index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-700' : 'bg-white'}`}
            >
              <div className="flex items-center mb-4">
                {Array(5).fill(0).map((_, i) => (
                  <Heart key={i} className="h-5 w-5 text-red-500 fill-current" />
                ))}
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                "我的孩子非常喜欢这个AI绘本！看到自己变成卡通形象在故事里冒险，他每天都要读好几遍。声音克隆功能也很棒，孩子听到我的声音讲故事特别开心。"
              </p>
              <div className="flex items-center">
                <div className="h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-500 mr-4">
                  <User className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-bold">李妈妈</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">3岁男孩的妈妈</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
       
        {/* 使用流程 */}
       <section className={`py-20 ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
         <div className="container mx-auto px-4">
           <motion.div 
             initial={{ opacity: 0 }}
             whileInView={{ opacity: 1 }}
             viewport={{ once: true }}
             className="text-center mb-16"
           >
             <h2 className="text-3xl md:text-4xl font-bold mb-4">简单几步，创造专属绘本</h2>
             <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
               只需几分钟，为您的孩子打造独一无二的童话故事
             </p>
           </motion.div>
           
           <div className="space-y-24">
             {/* 步骤1 */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="relative"
              >
                 <div className="absolute -left-4 top-0 w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white text-xl font-bold shadow-lg">
                   1
                 </div>
               <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 ml-8">
                 <div className="order-2 lg:order-1">
                   <h3 className="text-2xl font-bold mb-4">上传宝贝照片</h3>
                   <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg">
                     选择一张清晰的宝贝照片，我们的AI将分析面部特征，生成可爱的卡通形象
                   </p>
                   <ul className="space-y-3 text-gray-600 dark:text-gray-300">
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-blue-500 mt-1 text-lg"></i>
                       <span>确保照片光线充足，面部清晰可见</span>
                     </li>
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-blue-500 mt-1 text-lg"></i>
                       <span>支持正面、侧面等多种角度</span>
                     </li>
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-blue-500 mt-1 text-lg"></i>
                       <span>建议选择近期照片，效果更佳</span>
                     </li>
                   </ul>
                   <div className="mt-6 p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 text-sm">
                     宝贝的每一张照片，只为定制专属绘本而生 —— 加密存储、绝不外泄、自主可控，给孩子纯粹的专属体验，让家长放心托付～
                   </div>
                 </div>
                 <div className="order-1 lg:order-2 flex justify-center lg:justify-end">
                   <div className="w-full max-w-md h-96 rounded-xl overflow-hidden shadow-xl border-4 border-blue-100 dark:border-blue-900">
                     <img 
                       src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=upload%20child%20photo%20interface%2C%20happy%20family%20uploading%20baby%20photo%20for%20storybook%2C%20warm%20and%20colorful%20interface&sign=89cf5c8238f11fc4c014054bc7a006d3" 
                       alt="上传宝贝照片" 
                       className="w-full h-full object-cover"
                     />
                   </div>
                 </div>
               </div>
             </motion.div>
             
             {/* 步骤2 */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="relative"
              >
                 <div className="absolute -left-4 top-0 w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white text-xl font-bold shadow-lg">
                   2
                 </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 ml-8">
                 <div className="flex justify-center lg:justify-start">
                   <div className="w-full max-w-md h-96 rounded-xl overflow-hidden shadow-xl border-4 border-green-100 dark:border-green-900">
                     <img 
                       src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=storybook%20theme%20selection%20interface%2C%20colorful%20children%20book%20themes%20like%20underwater%2C%20jungle%2C%20space%2C%20castle%2C%20magical%20interface%20for%20parents%20to%20choose&sign=78450791f40bbd8232ff2a1e09a6645b" 
                       alt="选择绘本主题" 
                       className="w-full h-full object-cover"
                     />
                   </div>
                 </div>
                 <div>
                   <h3 className="text-2xl font-bold mb-4">选择绘本主题</h3>
                   <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg">
                     从多种精彩主题中选择，如海底世界、丛林探险、太空漫游等
                   </p>
                   <ul className="space-y-3 text-gray-600 dark:text-gray-300">
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-green-500 mt-1 text-lg"></i>
                       <span>每个主题都有独特的故事背景和角色</span>
                     </li>
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-green-500 mt-1 text-lg"></i>
                       <span>根据孩子的兴趣爱好选择合适的主题</span>
                     </li>
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-green-500 mt-1 text-lg"></i>
                       <span>支持自定义故事细节，让绘本更有意义</span>
                     </li>
                   </ul>
                 </div>
               </div>
             </motion.div>
             
             {/* 步骤3 */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="relative"
              >
                 <div className="absolute -left-4 top-0 w-10 h-10 rounded-full bg-purple-500 flex items-center justify-center text-white text-xl font-bold shadow-lg">
                   3
                 </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 ml-8">
                 <div className="order-2 lg:order-1">
                   <h3 className="text-2xl font-bold mb-4">生成专属绘本</h3>
                   <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg">
                     我们的AI将根据您提供的信息，自动生成12-18页的精美绘本
                   </p>
                   <ul className="space-y-3 text-gray-600 dark:text-gray-300">
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-purple-500 mt-1 text-lg"></i>
                       <span>生成过程约需3-5分钟，请耐心等待</span>
                     </li>
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-purple-500 mt-1 text-lg"></i>
                       <span>可添加个性化元素，如孩子的名字、朋友等</span>
                     </li>
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-purple-500 mt-1 text-lg"></i>
                       <span>专业插画师设计的模板，确保画面精美</span>
                     </li>
                   </ul>
                 </div>
                 <div className="order-1 lg:order-2 flex justify-center lg:justify-end">
                   <div className="w-full max-w-md h-96 rounded-xl overflow-hidden shadow-xl border-4 border-purple-100 dark:border-purple-900">
                     <img 
                       src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=AI%20generating%20children%20storybook%2C%20magical%20process%20of%20creating%20personalized%20book%20with%20child%27s%20face%2C%20progress%20animation%2C%20colorful%20and%20exciting%20interface&sign=fa2f95a0f1a6a4a3d6e9487f06e4cd19" 
                       alt="生成专属绘本" 
                       className="w-full h-full object-cover"
                     />
                   </div>
                 </div>
               </div>
             </motion.div>
             
             {/* 步骤4 */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="relative"
              >
                 <div className="absolute -left-4 top-0 w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-white text-xl font-bold shadow-lg">
                   4
                 </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 ml-8">
                 <div className="flex justify-center lg:justify-start">
                   <div className="w-full max-w-md h-96 rounded-xl overflow-hidden shadow-xl border-4 border-amber-100 dark:border-amber-900">
                     <img 
                       src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=storybook%20preview%20and%20download%20interface%2C%20parent%20and%20child%20previewing%20personalized%20book%2C%20download%20options%20for%20PDF%20and%20audio%2C%20happy%20and%20satisfied%20family%20moment&sign=798b934d2ce951f2cd203b09bc1a727b" 
                       alt="预览与下载" 
                       className="w-full h-full object-cover"
                     />
                   </div>
                 </div>
                 <div>
                   <h3 className="text-2xl font-bold mb-4">预览与下载</h3>
                   <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg">
                     绘本生成完成后，您可以预览全部内容，并选择下载PDF或添加AI语音朗读
                   </p>
                   <ul className="space-y-3 text-gray-600 dark:text-gray-300">
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-amber-500 mt-1 text-lg"></i>
                       <span>支持PDF下载打印，随时翻阅</span>
                     </li>
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-amber-500 mt-1 text-lg"></i>
                       <span>可选妈妈声音克隆，让孩子听到熟悉的声音</span>
                     </li>
                     <li className="flex items-start gap-3">
                       <i className="fa-regular fa-circle-check text-amber-500 mt-1 text-lg"></i>
                       <span>随时分享给亲友，共同感受阅读的乐趣</span>
                     </li>
                   </ul>
                 </div>
               </div>
             </motion.div>
           </div>
         </div>
       </section>

       {/* 行动召唤 */}
      <section className={`py-20 ${isDark ? 'bg-gray-800' : 'bg-blue-50'}`}>
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">开始创造专属绘本吧！</h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-10">
              只需简单几步，为您的孩子创造一份珍贵的童年回忆
            </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-full shadow-lg hover:shadow-xl transition-all text-lg"
              >
                立即开始创作
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-white dark:bg-gray-800 text-gray-800 dark:text-white font-semibold rounded-full shadow-lg hover:shadow-xl transition-all border border-gray-200 dark:border-gray-700 text-lg"
                onClick={() => alert('意见反馈功能开发中，敬请期待！')}
              >
                意见反馈
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>
      
        {/* 意见反馈与联系信息 */}
       <section className={`py-12 ${isDark ? 'bg-gray-800' : 'bg-blue-50'}`}>
         <div className="container mx-auto px-4">
           <div className="max-w-3xl mx-auto text-center">
             <h2 className="text-2xl font-bold mb-6">联系我们</h2>
             <div className="flex flex-col md:flex-row justify-center gap-8">
               <div className="flex-1">
                 <div className="bg-white dark:bg-gray-700 rounded-xl shadow-lg p-6">
                   <div className="mb-4 inline-block p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                     <i className="fa-solid fa-envelope text-xl text-blue-500"></i>
                   </div>
                   <h3 className="text-lg font-semibold mb-2">邮箱联系</h3>
                   <p className="text-gray-600 dark:text-gray-300 mb-4">
                     有任何问题或建议，欢迎随时联系我们
                   </p>
                    <a 
                      href="mailto:5249733@qq.com" 
                      className="inline-block px-6 py-14 bg-blue-100 hover:bg-blue-200 text-blue-600 dark:bg-blue-900 dark:hover:bg-blue-800 dark:text-blue-100 font-medium rounded-lg transition-all flex items-center justify-center"
                    >
                      5249733@qq.com
                    </a>
                 </div>
               </div>
               <div className="flex-1">
                 <div className="bg-white dark:bg-gray-700 rounded-xl shadow-lg p-6">
                   <div className="mb-4 inline-block p-3 bg-green-100 dark:bg-green-900 rounded-full">
                     <i className="fa-brands fa-weixin text-xl text-green-500"></i>
                   </div>
                   <h3 className="text-lg font-semibold mb-2">微信联系</h3>
                   <p className="text-gray-600 dark:text-gray-300 mb-4">
                     扫描二维码添加微信客服
                   </p>
                   {/* 微信二维码占位区 */}
                   <div className="w-32 h-32 mx-auto bg-gray-200 dark:bg-gray-600 rounded-lg flex items-center justify-center">
                     <p className="text-sm text-gray-500 dark:text-gray-400">二维码预留位置</p>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </section>
      
      {/* 页脚 */}
      <footer className={`py-6 ${isDark ? 'bg-gray-900 text-gray-300' : 'bg-gray-100 text-gray-600'}`}>
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
             <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <BookOpen className="h-6 w-6 text-blue-500" />
              <span className="text-lg font-bold">小故事家</span>
            </div>
             <div className="text-sm">
              © 2025 小故事家. 保留所有权利.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}