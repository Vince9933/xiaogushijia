import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';
import {
  Server,
  Code,
  Globe,
  CheckCircle,
  Download,
  Terminal,
  Upload,
  Database,
  Settings,
  ArrowRight,
  BookOpen
} from 'lucide-react';

export default function DeployGuide() {
  const { theme, isDark } = useTheme();

  // 部署步骤数据
  const deploymentSteps = [
    {
      title: "1. 准备开发环境",
      description: "确保您的电脑上安装了Node.js和npm/pnpm/yarn等包管理工具",
      icon: <Code className="h-10 w-10 text-blue-500" />,
      details: [
        "安装Node.js（建议版本16.x或更高）",
        "安装pnpm: npm install -g pnpm",
        "克隆项目代码到本地"
      ]
    },
    {
      title: "2. 安装依赖",
      description: "在项目根目录下运行命令安装所需的依赖包",
      icon: <Download className="h-10 w-10 text-green-500" />,
      details: [
        "运行: pnpm install",
        "等待依赖安装完成"
      ],
      command: "pnpm install"
    },
    {
      title: "3. 本地开发测试",
      description: "启动本地开发服务器，在浏览器中预览网站",
      icon: <Server className="h-10 w-10 text-yellow-500" />,
      details: [
        "运行: pnpm dev",
        "打开浏览器访问: http://localhost:3000",
        "测试所有功能是否正常工作"
      ],
      command: "pnpm dev"
    },
    {
      title: "4. 构建生产版本",
      description: "生成用于部署的优化后的生产版本文件",
      icon: <Terminal className="h-10 w-10 text-purple-500" />,
      details: [
        "运行: pnpm build",
        "等待构建过程完成",
        "检查dist目录是否生成"
      ],
      command: "pnpm build"
    },
    {
      title: "5. 部署到服务器",
      description: "将构建后的文件部署到您选择的托管平台",
      icon: <Upload className="h-10 w-10 text-red-500" />,
      details: [
        "选择部署平台（Vercel、Netlify、GitHub Pages等）",
        "按照平台指引上传dist目录内容",
        "配置域名和HTTPS"
      ]
    },
    {
      title: "6. 配置后端服务（可选）",
      description: "如果需要真实后端API，配置相应的服务",
      icon: <Database className="h-10 w-10 text-indigo-500" />,
      details: [
        "设置云存储服务（如AWS S3、阿里云OSS等）",
        "配置AI服务API密钥（如图片生成、语音合成等）",
        "部署后端API服务（如需要）"
      ]
    },
    {
      title: "7. 监控与维护",
      description: "定期检查网站运行状态，更新内容和修复问题",
      icon: <Settings className="h-10 w-10 text-gray-500" />,
      details: [
        "设置网站访问统计",
        "定期更新依赖包版本",
        "监控服务器性能和错误日志"
      ]
    }
  ];

  // 部署平台推荐
  const deploymentPlatforms = [
    {
      name: "Vercel",
      description: "简单快速的前端部署平台，支持自动构建和CI/CD",
      url: "https://vercel.com/",
      recommended: true
    },
    {
      name: "Netlify",
      description: "提供托管、构建和部署服务的平台，易于使用",
      url: "https://www.netlify.com/",
      recommended: true
    },
    {
      name: "GitHub Pages",
      description: "免费的静态网站托管服务，与GitHub代码仓库集成",
      url: "https://pages.github.com/",
      recommended: true
    },
    {
      name: "阿里云OSS",
      description: "阿里云对象存储服务，适合中国境内用户",
      url: "https://www.aliyun.com/product/oss",
      recommended: false
    },
    {
      name: "腾讯云COS",
      description: "腾讯云对象存储服务，提供稳定的存储和分发能力",
      url: "https://cloud.tencent.com/product/cos",
      recommended: false
    }
  ];

  return (
    <div className={cn('min-h-screen py-8', isDark ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-800')}>
      <div className="container mx-auto px-4 max-w-5xl">
        {/* 页面标题 */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 text-center"
        >
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
              <Globe className="h-8 w-8 text-blue-500" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">网站上线部署指南</h1>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            按照以下步骤，您可以轻松将AI儿童绘本网站上线并进行实际测试
          </p>
        </motion.div>

        {/* 快速入门卡片 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className={`p-6 rounded-xl shadow-lg mb-12 ${isDark ? 'bg-gray-800' : 'bg-white'}`}
        >
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
            快速部署步骤
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
              <h3 className="font-bold mb-2">1. 本地准备</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">安装依赖并测试功能</p>
            </div>
            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
              <h3 className="font-bold mb-2">2. 构建项目</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">生成优化的生产版本</p>
            </div>
            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
              <h3 className="font-bold mb-2">3. 部署上线</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">上传文件到托管平台</p>
            </div>
          </div>
        </motion.div>

        {/* 详细部署步骤 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold mb-6 text-center">详细部署步骤</h2>
          <div className="space-y-8">
            {deploymentSteps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}
              >
                <div className="flex flex-col md:flex-row md:items-start gap-4">
                  <div className="flex-shrink-0 p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                    {step.icon}
                  </div>
                  <div className="flex-grow">
                    <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{step.description}</p>
                    
                    <ul className="space-y-2 mb-4">
                      {step.details.map((detail, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <ArrowRight className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-600 dark:text-gray-300">{detail}</span>
                        </li>
                      ))}
                    </ul>
                    
                    {step.command && (
                      <div className={`p-3 rounded-lg font-mono text-sm ${isDark ? 'bg-gray-900' : 'bg-gray-100'}`}>
                        {step.command}
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* 部署平台推荐 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold mb-6 text-center">推荐部署平台</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {deploymentPlatforms.map((platform, index) => (
              <motion.div
                key={index}
                whileHover={{ y: -5 }}
                className={`p-6 rounded-xl shadow-lg ${
                  isDark ? 'bg-gray-800' : 'bg-white'
                } ${platform.recommended ? 'border-2 border-green-500' : ''}`}
              >
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-bold">{platform.name}</h3>
                  {platform.recommended && (
                    <span className="text-xs bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-1 rounded-full">
                      推荐
                    </span>
                  )}
                </div>
                <p className="text-gray-600 dark:text-gray-300 mb-4">{platform.description}</p>
                <a 
                  href={platform.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-500 hover:text-blue-600 flex items-center"
                >
                  访问官网 <ArrowRight className="ml-1 h-4 w-4" />
                </a>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* 实际测试指南 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className={`p-6 rounded-xl shadow-lg mb-12 ${isDark ? 'bg-gray-800' : 'bg-white'}`}
        >
          <h2 className="text-2xl font-bold mb-4">网站上线后测试指南</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-bold mb-2">功能测试</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-2">
                网站上线后，请全面测试以下功能：
              </p>
              <ul className="space-y-2 ml-6">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>照片上传功能是否正常</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>主题选择功能是否正常</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>绘本生成功能是否正常（实际环境可能需要配置AI服务）</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>语音合成功能是否正常（实际环境可能需要配置语音API）</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>PDF下载功能是否正常</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-bold mb-2">性能测试</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-2">
                使用以下工具测试网站性能：
              </p>
              <ul className="space-y-2 ml-6">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Google PageSpeed Insights - 测试页面加载速度</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Lighthouse - 综合评估网站性能、可访问性等</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>WebPageTest - 多地区访问速度测试</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-bold mb-2">兼容性测试</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-2">
                在不同浏览器和设备上测试网站兼容性：
              </p>
              <ul className="space-y-2 ml-6">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>桌面浏览器：Chrome、Firefox、Safari、Edge</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>移动设备：iOS Safari、Android Chrome</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>确保响应式布局在不同屏幕尺寸下正常显示</span>
                </li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* 注意事项 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-amber-900/30' : 'bg-amber-50'}`}
        >
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Settings className="h-5 w-5 mr-2 text-amber-500" />
            注意事项
          </h2>
          <ul className="space-y-3">
            <li className="flex items-start gap-2">
              <ArrowRight className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <span>当前版本使用模拟数据，如果需要真实的AI功能，需要集成相应的API服务</span>
            </li>
            <li className="flex items-start gap-2">
              <ArrowRight className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <span>部署前请确保修改配置文件中的API密钥等敏感信息</span>
            </li>
            <li className="flex items-start gap-2">
              <ArrowRight className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <span>定期备份网站数据和代码，以防数据丢失</span>
            </li>
            <li className="flex items-start gap-2">
              <ArrowRight className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <span>确保网站符合相关法律法规，特别是关于儿童数据保护的规定</span>
            </li>
          </ul>
        </motion.div>

        {/* 回到首页按钮 */}
        <div className="mt-12 text-center">
          <motion.a
            href="/"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white font-semibold rounded-full transition-all"
          >
            <BookOpen className="mr-2 h-5 w-5" />
            回到首页
          </motion.a>
        </div>
      </div>
    </div>
  );
}